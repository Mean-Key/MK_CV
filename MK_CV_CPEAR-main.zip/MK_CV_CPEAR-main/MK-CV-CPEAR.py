import cv2 as cv
import numpy as np

# --- 입력 파일 및 카메라 파라미터 ---
video_file = 'chess_video.mp4'
K = np.array([[432.7390364738057, 0, 476.0614994349778],
              [0, 431.2395555913084, 288.7602152621297],
              [0, 0, 1]])
dist_coeff = np.array([-0.2852754904152874, 0.1016466459919075, -0.0004420196146339175,
                       0.0001149909868437517, -0.01803978785585194])
board_pattern = (9, 6)
board_cellsize = 0.025  # 단위: 미터

# --- 체스보드 3D 포인트 생성 ---
obj_points = board_cellsize * np.array([[c, r, 0]
                                        for r in range(board_pattern[1])
                                        for c in range(board_pattern[0])])

# --- AR 알파벳 "M"과 "K" 3D 좌표 (Z=0 평면) ---
M_points = board_cellsize * np.array([
    [2.0, 5.0, 0], [2.0, 2.0, 0],
    [2.0, 2.0, 0], [3.0, 3.5, 0],
    [3.0, 3.5, 0], [4.0, 2.0, 0],
    [4.0, 2.0, 0], [4.0, 5.0, 0],
])

K_points = board_cellsize * np.array([
    [5.0, 5.0, 0], [5.0, 2.0, 0],
    [5.0, 3.5, 0], [6.0, 2.0, 0],
    [5.0, 3.5, 0], [6.0, 5.0, 0],
])

# --- 영상 열기 ---
cap = cv.VideoCapture(video_file)
assert cap.isOpened(), 'Cannot open video file.'

# --- 출력 영상 설정 ---
ret, sample_frame = cap.read()
h, w = sample_frame.shape[:2]
cap.set(cv.CAP_PROP_POS_FRAMES, 0)
fourcc = cv.VideoWriter_fourcc(*'mp4v')
out = cv.VideoWriter('output_AR_MK.mp4', fourcc, 30, (w, h))

# --- 메인 루프 ---
while True:
    ret, frame = cap.read()
    if not ret:
        break

    found, corners = cv.findChessboardCorners(frame, board_pattern)
    if found:
        gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
        corners_refined = cv.cornerSubPix(
            gray, corners, (11, 11), (-1, -1),
            (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 30, 0.001)
        )

        # 자세 추정
        ret, rvec, tvec = cv.solvePnP(obj_points, corners_refined, K, dist_coeff)

        # --- AR 도형 투영 ---
        M_imgpts, _ = cv.projectPoints(M_points, rvec, tvec, K, dist_coeff)
        K_imgpts, _ = cv.projectPoints(K_points, rvec, tvec, K, dist_coeff)
        M_imgpts = M_imgpts.astype(int).reshape(-1, 2)
        K_imgpts = K_imgpts.astype(int).reshape(-1, 2)

        # --- "M" 그리기 (노란색)
        for i in range(0, len(M_imgpts), 2):
            cv.line(frame, tuple(M_imgpts[i]), tuple(M_imgpts[i + 1]), (0, 255, 255), 3)

        # --- "K" 그리기 (하늘색)
        for i in range(0, len(K_imgpts), 2):
            cv.line(frame, tuple(K_imgpts[i]), tuple(K_imgpts[i + 1]), (255, 255, 0), 3)

        # --- 카메라 위치 출력
        R, _ = cv.Rodrigues(rvec)
        cam_pos = (-R.T @ tvec).flatten()
        text = f"Camera XYZ: [{cam_pos[0]:.2f}, {cam_pos[1]:.2f}, {cam_pos[2]:.2f}]"
        cv.putText(frame, text, (10, 30), cv.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

    # --- 결과 영상 보기 (축소된 창)
    scale = 0.4
    display = cv.resize(frame, None, fx=scale, fy=scale)
    cv.imshow('AR MK Visualization', display)
    out.write(frame)

    if cv.waitKey(10) == 27:  # ESC 키
        break

cap.release()
out.release()
cv.destroyAllWindows()
