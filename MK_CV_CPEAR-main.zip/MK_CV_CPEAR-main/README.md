# MK's Camera Pose Estimation and AR

## 📌 개요
이 프로그램은 OpenCV를 사용하여 촬영한 영상의 카메라의 자세를 알아내고 (Camera Pose Estimation) 영상에 다른 AR 물체 표시하는 프로그램입니다.   

## :computer: 기능 소개

## Camera Pose Estimation (카메라 자세 추정)

- **카메라 영상에서 체스보드 패턴 감지**
```python
found, corners = cv.findChessboardCorners(frame, board_pattern)
```

- **감지된 코너의 위치를 서브픽셀 단위로 정밀화**
```python
gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
corners_refined = cv.cornerSubPix(
    gray, corners, (11, 11), (-1, -1),
    (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 30, 0.001)
)
```

- **내 카메라의 위치와 방향을 추정**
```python
ret, rvec, tvec = cv.solvePnP(obj_points, corners_refined, K, dist_coeff)
```

- **회전 벡터를 회전 행렬로 변환**
```python
R, _ = cv.Rodrigues(rvec)
cam_pos = (-R.T @ tvec).flatten()
```

- **계산된 카메라 위치를 영상에 텍스트로 표시**
```python
cv.putText(frame, text, (10, 30), cv.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
```

## AR object visualization (AR 객체 시각화)

- **체스보드 위에 위치한 글자의 3D 좌표 정**
```python
# 알파벳 "M"과 "K" 3D 좌표 정의
M_points = board_cellsize * np.array([...])
K_points = board_cellsize * np.array([...])
```

- **3D 좌표 → 2D 영상 좌표로 변환**
```python
# 카메라 자세를 기반으로 M, K 점들을 2D 이미지 좌표로 투영
M_imgpts, _ = cv.projectPoints(M_points, rvec, tvec, K, dist_coeff)
K_imgpts, _ = cv.projectPoints(K_points, rvec, tvec, K, dist_coeff)
```
- **2D로 투영된 점들을 cv.line()으로 연결**
```python
# 선 그리기로 "M", "K" 시각화
for i in range(0, len(M_imgpts), 2):
    cv.line(frame, tuple(M_imgpts[i]), tuple(M_imgpts[i+1]), (0, 255, 255), 3)

for i in range(0, len(K_imgpts), 2):
    cv.line(frame, tuple(K_imgpts[i]), tuple(K_imgpts[i+1]), (255, 255, 0), 3)
```

## AR 물체 표시 결과 데모
- **M K** 글자 표시 (결과 동영상 스크린샷) - [MK : 민기]
<img src="https://github.com/Mean-Key/MK_CV_CPEAR/blob/main/result.png"/>

- 원본 동영상 chess_video.mp4
<img width="50%" src="https://github.com/Mean-Key/MK_CV_CPEAR/blob/main/chess_video.gif"/>

- Camera pose estimation, ARobject visualization 적용 동영상 output_AR_MK.mp4
<img width="50%" src="https://github.com/Mean-Key/MK_CV_CPEAR/blob/main/output_AR_MK.gif"/>
